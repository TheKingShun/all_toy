from llvmlite import ir
import re
import sol_type as T
import os
import llvm_header
import logging 
import fun2llvm as f2l
import gv2llvm as gv2l
import fun_body2llvm as fb2l


logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s %(filename)s [line:%(lineno)d] ===%(levelname)s=== %(message)s',  # 显示格式
    datefmt='%Y %m %d',  # 日期
)


current_system = 'ubuntu-20.04'

module = None
fun_map = {}  #this  store all funs map to ir function 

def deal_raw_solidity(path):
    global fun_map
    global module
    functions = []
    tmp = ''
    ret = ''
    inside_function = False
    g_var = []
    contract_name = ''
    contract_version = ''
    if(os.path.exists(path) and os.path.isfile(path)):
        with open(path,'r')as f:
            for line in f.readlines():
                line = line.strip()

                line = delete_comments_or_zero(line)
                if(line == ''):
                    continue

                ret += line+'\n'

                if(line.startswith('pragma')):
                    line = line.replace('pragma','')
                    line = line.replace('solidity','')
                    contract_version = line.strip()
                    logging.info(contract_version)
                    continue

                if(line.startswith('contract')):
                    line = line.replace('contract','')
                    line = line.strip()
                    for i in line:
                        if(i == '\n' or i == '{' ):
                            break
                        contract_name+=i
                    module = ir.Module(name = contract_name)
                    logging.info(contract_name)
                    continue

                if(line.startswith('function')):
                    inside_function = True
                    if(tmp != ''):functions.append(tmp)
                    tmp = ''
                    tmp +=line+'\n'
                    continue

                if(inside_function):
                    tmp+=line+'\n'
                    continue

                if ( not inside_function ):
                    if(gv2l.gv_no_init(module,line,g_var)):
                        logging.info('gv_no_init:'+line)
                        continue 
                    if(gv2l.gv_with_init(module,line,g_var)):
                        logging.info('gv_with_init:'+line)
                        continue 
        # print(ret)

                    

        if(tmp != ''):
            functions.append(tmp) 
        # delete the last function more }
        functions[-1] = functions[-1][0:-2]
    # print('================================================')
    # print(g_var)
    # print('************************************************')
    # print('=================functions===========================')
    # print((functions))

    if(module is None):
        module = ir.Module(name = contract_name)
    module.data_layout = llvm_header.header[current_system]['datalayout']
    module.triple = llvm_header.header[current_system]['triple']

        
    for i in functions:
        import build_funs as bf
        bf.builds(fun_map,module,i)                                 #get all functions declare into this var:fun_map
    
    import fun_body2llvm as fb2l
    fb2l.prepare2ir(module,fun_map,g_var)                                 #deal all declared functions 



    # for i in functions:
    #     expr_fun = i
    #     args = module,expr_fun,g_var,fun_map_ir
    #     f2l.process_fun(*args)
    print("==========fun_map===============")
    print(fun_map)

    #     # mod,func,builder,body,gv,fun_para_2_ir_para = args
    #     # func,builder,fun_body,fun_para_2_ir_para
    # for k,v in fun_map_ir.items():
    #     fb2l.body2ir()
    #     return 
    print("====================module=============================")
    print(module)




def delete_comments_or_zero(line):

    if(len(line)==0 or line.startswith('/*') or line.startswith('*') or line.startswith('//')):
        return ''
    
    if('//' in line ):
        line = line.split('//')[0]
    
    return line


if __name__ == "__main__":
    path = '../tmp/varible.sol'
    deal_raw_solidity(path)