from llvmlite import ir

double = ir.DoubleType()

uint8 = ir.IntType(8)
uint16 = ir.IntType(16)
uint32 = ir.IntType(32)
uint = ir.IntType(256)
uint256 = ir.IntType(256)

void = ir.VoidType()


all_types ={
    'uint8':uint8,
    'uint16':uint16,
    'uint32':uint32,
    'uint':uint,
    'uint256':uint256,
    'void':void
}

type_list = ['uint8','uint16','uint32','uint','uint256','void']


# if __name__ == "__main__":
#     print(uint8)








