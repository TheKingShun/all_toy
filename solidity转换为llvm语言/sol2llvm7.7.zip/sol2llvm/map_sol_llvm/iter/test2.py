import sol_type as T
a = {'a': 'uint', 'b': 'uint32', 'c': 'uint8'}
for i in a.items():
    s,t = i
    t = T.all_types[t]
    print(s,t)


for i in a:
    print(i)

print(a.keys())

print(tuple(a))
print(len(a))