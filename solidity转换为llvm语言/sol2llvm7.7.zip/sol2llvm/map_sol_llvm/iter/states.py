ERROR = 'error'
OK = 'ok'