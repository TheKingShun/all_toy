from llvmlite import ir
import re
import sol_type as T
import os
import llvm_header
import logging 


module = None

def get_para(expr):
    pattern = re.compile(r'[(](.*?)[)]' ,re.S)
    args_str = str(re.findall(pattern,expr)[0])
    logging.info('args_str:'+args_str)
    return args_str  

def analy_para(expr):
    # expr like uint a,uint b
    dict_para = {}
    paralist = expr.split(',')
    for i in paralist:
        temp = i.strip().split(' ')
        logging.info(temp)
        if(len(temp) == 1):
            dict_para['_result'] = temp[0]
        else:
            dict_para[temp[1]] = temp[0]
    return dict_para


def define_function(module_pre,expr):
    global module
    module = module_pre
    function_name =''
    function_args = {}
    returns_args = {}
    function_body = ''
    returns_body = None

    if(expr.find('function') != 0):
        return False
    if('returns' in expr):
        tmp = expr.split('returns')
        # reutrn dist of args
        returns_body = tmp[-1]  
        returns_args = analy_para(get_para(returns_body))
        logging.info('returns_args:')
        logging.info(returns_args)

    function_body = tmp[0]
    function_args = analy_para(get_para(function_body))
    logging.info('function_args:')
    logging.info(function_args)

    # delete the (context)
    function_body.strip()
    function_body = function_body.replace('('," (")
    function_body = function_body.replace(')',") ")
    out = re.sub(r'\(.*?\)', '', function_body)

    function_info = [x for x in out.split(' ') if x!='']
    print(function_info)
    function_name = function_info[1]
    logging.info(function_name)

    define_fun_llvm(function_name,function_args,returns_args)
    return True

def define_fun_llvm(function_name,function_args,returns_args=None):
    args_name = []
    args_ir_type = []
    ret_name ='ret'
    ret_type =None

    for name,typ in function_args.items():
        print("args_name is:"+name)
        args_name.append(name)
        args_ir_type.append(T.all_types[typ])

    if(len(returns_args) == 1):
        for ret_na,ret_typ in returns_args.items():
            ret_name += ret_na
            ret_type = T.all_types[ret_typ]
    
    func_llvm(function_name,args_name,args_ir_type,ret_name,ret_type)
    return 



def func_llvm(function_name,args_name,args_ir_type,ret_name,ret_type):
    global module
    logging.info(type(args_ir_type))
    if(ret_type is None):
        fnty = ir.FunctionType(T.void,args_ir_type)
    else:
        fnty = ir.FunctionType(ret_type,args_ir_type)

    args_ir_list = []
    for i in range(len(args_name)):
        args_ir_list.append(ir.Argument(module,args_ir_type[i],args_name[i]))

    # fnty.args = (T.double,T.double)
    func = ir.Function(module,fnty,name=function_name)
    func.args = tuple(args_ir_list)
    # func.is_declaration = False
    block = func.append_basic_block(name="start")
    builder = ir.IRBuilder(block)
    # # logging.info(args_name[0])
    # args_c = args_name.copy()
    # args_name = func.args
    # args = dict(zip(args_c,args_name))
    # logging.info(args)
    # builder.fadd(eval('a'),eval('b'),name='res')
    ret_res = builder.fadd(T.uint(1),T.uint(32))
    print("ret_res"+str(type(ret_res)))
    builder.ret(ret_res)
    # func.attributes.add("alwaysinline")
    # print(module)