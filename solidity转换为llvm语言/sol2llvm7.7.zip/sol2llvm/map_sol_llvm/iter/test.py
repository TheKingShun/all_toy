
import json
import re
from llvmlite import ir
import sol_type as T
import llvm_header 
import logging 
import os

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s %(filename)s [line:%(lineno)d] ===%(levelname)s=== %(message)s',  # 显示格式
    datefmt='%Y %m %d',  # 日期
)
# json_data = []



# def delete_redun_lines(filename, count):
#     fin = open(filename, 'r')
#     a = fin.readlines()
#     fout = open(filename, 'w')
#     b = ''.join(a[count:])
#     fout.write(b)


# # with open('../00.txt','r')as f:
# #     raw_data = f.read()
# #     json_data = json.loads(raw_data)


# # keys = json_data.keys()
# # for i in keys:
# #     print (i)
# #     print ('json_data[{}]:{}\n'.format(i,json_data[i]))

# # with open("../00.txt",'r')as f:
# #     print(f.read())


# if __name__ == "__main__":
#     str = "ContractDefinition \"DemoTypes\""
#     pattern = re.compile("\"(.*)\"")
#     print(pattern.findall(str)[0])
#     # delete_redun_lines('../00.txt',4)

# str = ' function fun1(uint a)pure public returns (uint b) {'
# print(str.strip().find('function'))
# print(str.strip().find('fun1'))
# print(str.find('fun2'))
# lines = ''
# with open("../no_brace",'r')as f:
#     lines = f.read()

# lines = lines.replace('{','')
# lines = lines.replace('}','')
# lines = lines.replace(';','')

# with open("../no_brace_com",'w')as f:
#     f.write(lines)

# raw_data = []
# for line in open("../no_brace_com",'r'):
#     line = line.strip()
#     line = line.replace('\n','')
#     if(line != ''):
#         raw_data.append(line)
    

# # print(raw_data)

# module = ir.Module(name = 'contract_name')
# module.data_layout = llvm_header.header['system']['datalayout']
# module.triple = llvm_header.header['system']['triple']

# # gv = ir.GlobalVariable(module,T.uint32, 'name', addrspace=0)
# # gv.initializer = T.uint32(1)
# # module.add_global(ir.GlobalValue)


# # # ir.MetaDataString(module,'MetaDataString')
# print(module)
# a = 'uint year = 2021'
# a = a.replace('=','').split(' ')
# a = [x for x in a if x!='']
# print(a)

# s = "  ===   "
# print(s)
# s = s.strip()
# print(s)




import re
# modifier_no_supported = ['pure','private','external','internal','view','constant','payable']
# modifier_supported = ['public','return']

# function_body = ''
# returns_body = None





# FUN_ARGS = 1
# RETURNS_ARGS = 2






# t = 'function fun1(uint a,uint b)pure public returns (uint b)'






# # get function and the return body params
# get_para(function_body)
# if(returns_body is not None):
#     get_para(returns_body,RETURNS_ARGS)






# # =======================================================================================


# module  = ir.Module(name = 'dfsdfsdf')

# FUN_ARGS = 1
# RET_ARGS = 2

# def get_para(expr):
#     pattern = re.compile(r'[(](.*?)[)]' ,re.S)
#     args_str = str(re.findall(pattern,expr)[0])
#     logging.info('args_str:'+args_str)
#     return args_str  

# def analy_para(expr):
#     # expr like uint a,uint b
#     dict_para = {}
#     paralist = expr.split(',')
#     for i in paralist:
#         temp = i.strip().split(' ')
#         dict_para[temp[1]] = temp[0]
#     return dict_para


# def define_function(expr):

#     function_name =''
#     function_args = {}
#     returns_args = {}
#     function_body = ''
#     returns_body = None

#     if(expr.find('function') != 0):
#         return False
#     if('returns' in expr):
#         tmp = expr.split('returns')
#         # reutrn dist of args
#         returns_body = tmp[-1]  
#         returns_args = analy_para(get_para(returns_body))
#         logging.info('returns_args:')
#         logging.info(returns_args)

#     function_body = tmp[0]
#     function_args = analy_para(get_para(function_body))
#     logging.info('function_args:')
#     logging.info(function_args)

#     # delete the (context)
#     function_body.strip()
#     function_body = function_body.replace('('," (")
#     function_body = function_body.replace(')',") ")
#     out = re.sub(r'\(.*?\)', '', function_body)

#     function_info = [x for x in out.split(' ') if x!='']
#     print(function_info)
#     function_name = function_info[1]
#     logging.info(function_name)

#     define_fun_llvm(function_name,function_args,returns_args)

# def define_fun_llvm(function_name,function_args,returns_args=None):
#     args_name = []
#     args_ir_type = []
#     ret_name ='ret'
#     ret_type =None

#     for name,typ in function_args.items():
#         print("args_name is:"+name)
#         args_name.append(name)
#         args_ir_type.append(T.all_types[typ])
#     if(len(returns_args) == 1):
#         for ret_na,ret_typ in function_args.items():
#             ret_name += ret_na
#             ret_type = T.all_types[ret_typ]
    
#     func_llvm(function_name,args_name,args_ir_type,ret_name,ret_type)
#     return 



# def func_llvm(function_name,args_name,args_ir_type,ret_name,ret_type):
#     global module
#     logging.info(type(args_ir_type))
#     if(ret_type is None):
#         fnty = ir.FunctionType(T.void,args_ir_type)
#     else:
#         fnty = ir.FunctionType(ret_type,args_ir_type)

#     args_ir_list = []
#     for i in range(len(args_name)):
#         args_ir_list.append(ir.Argument(module,args_ir_type[i],args_name[i]))

#     # fnty.args = (T.double,T.double)
#     func = ir.Function(module,fnty,name=function_name)
#     func.args = tuple(args_ir_list)
#     # func.is_declaration = False
#     block = func.append_basic_block(name="start")
#     builder = ir.IRBuilder(block)
#     # # logging.info(args_name[0])
#     # args_c = args_name.copy()
#     # args_name = func.args
#     # args = dict(zip(args_c,args_name))
#     # logging.info(args)
#     # builder.fadd(eval('a'),eval('b'),name='res')
#     ret_res = builder.fadd(T.uint(1),T.uint(32))
#     print("ret_res"+str(type(ret_res)))
#     builder.ret(ret_res)
#     # func.attributes.add("alwaysinline")
#     print(module)

# dealed_path = './dealed.txt'



# def get_raw_data():
#     raw_data = []
#     for line in open(dealed_path,'r'):
#         line = line.strip()
#         line = line.replace('\n','')
#         if(line != ''):
#             raw_data.append(line)
#             # //todo
        
#     print(raw_data)

# module = ir.Module(name = "__test__")

# def deal_raw_solidity(path):
#     global module
#     functions = []
#     tmp = ''
#     ret = ''
#     inside_function = False
#     gv_define = ''
#     if(os.path.exists(path) and os.path.isfile(path)):
#         with open(path,'r')as f:
#             for line in f.readlines():
#                 line = line.strip()
#                 if(len(line)==0 or line.startswith('/*') or line.startswith('*')):
#                     continue
#                 ret += line+'\n'
#                 if(line.startswith('function')):
#                     inside_function = True
#                     if(tmp != ''):functions.append(tmp)
#                     tmp = ''
#                     tmp +=line+'\n'
#                     continue
#                 if(line.startswith('return') and not line.startswith('returns')):
#                     tmp+=line+'\n'
#                     tmp +='}'
#                     functions.append(tmp)
#                     tmp = ''
#                     inside_function = False
#                     continue
#                 if(inside_function):
#                     tmp+=line+'\n'
#                     continue

#         if(tmp != ''):
#             functions.append(tmp) 
#         # delete more }
#         if('returns' not in functions[-1]):
#             functions[-1] = functions[-1][0:-2]

#     print('=================')

#     for i in functions:
#         expr_fun = i
#         process_fun(expr_fun)

#         logging.info("expr_fun===\n"+expr_fun)

#         logging.info(module)


# def process_fun(expr_fun):
#     # pattern = re.compile(r'[(](.*?)[)]' ,re.S)
#     # args_str = str(re.findall(pattern,expr)[0])
#     global module
#     fun_name = ''
#     fun_args = {}
#     ret_args = None
#     fun_body = (str(re.findall(re.compile(r'[{](.*)[}]', re.S), expr_fun)[0]))
#     print('===============')
#     print(fun_body)
#     print('===============')
#     expr = expr_fun.replace('function','')
#     for i in expr:
#         if(i == '('):
#             break
#         else:
#             fun_name+=i
#     fun_name = fun_name.strip()
#     logging.info('fun name:==='+fun_name)
#     expr = expr.replace(fun_name,'')
#     fun_args_str = ''
#     for i in expr:
#         fun_args_str+=i
#         if(i == ')'):
#             break
#     fun_args_str = fun_args_str.strip()
#     logging.info('fun args:=='+fun_args_str)
#     # get the function args returns the dict
#     fun_args = get_fun_args(fun_args_str)
#     logging.info(fun_args)
#     if('returns' in expr):
#         expr = expr.split('returns')[1]
#         # get the ret value
#         ret_args = get_ret_args(expr)
#         # logging.info('returns==='+expr)
#         logging.info('ret_args===')
#         logging.info(ret_args)
#     # creat the function LLVM
#     logging.info(fun_args)
#     fun2ir(fun_name,fun_args,ret_args,fun_body)

# def fun2ir(fun_name,fun_args,ret_args,fun_body):
#     global module
#     ret_para = None
#     ret_type = None
#     fun_para = []
#     fun_type = []
#     fun_para_2_ir_para = {}
#     logging.info(fun_args)
#     # for i in fun_args.items():
#     #     p,t = i
#     #     fun_para_2_ir_para[p] = T.all_types[t]
#     # logging.info('fun_para_2_ir_para===')
#     # logging.info(fun_para_2_ir_para)

#     if(ret_args is not None and len(ret_args)!=0):
#         logging.info('ret_args length is '+str(len(ret_args)))
#         for para,typ in ret_args.items():
#             logging.info(para)
#             logging.info(typ)
#             ret_type = T.all_types[typ]
    

#     for para ,typ in fun_args.items():
#         logging.info(para)
#         logging.info(typ)
#         fun_para.append(para)
#         fun_type.append(T.all_types[typ])
#     logging.info(fun_type)
#     if(ret_type is None):
#         fnty = ir.FunctionType(T.void,fun_type)
#     else:
#         fnty = ir.FunctionType(ret_type,fun_type)
    

#     func = ir.Function(module,fnty,name=fun_name)
#     # func.args = tuple(fun_para_2_ir_para)
#     args_ir_para = func.args
#     fun_para_2_ir_para = dict(zip(tuple(fun_args),args_ir_para))
#     logging.info(fun_para_2_ir_para)

#     block = func.append_basic_block(name="start")
#     builder = ir.IRBuilder(block)
    
    

# def get_ret_args(expr):
#     args_list = []
#     args_str = ''
#     for i in expr:
#         args_str += i
#         if(i ==')'):
#             break
#     # logging.info('args_str==='+args_str)
#     args_str = args_str.replace('(','')
#     args_str = args_str.replace(')','')
#     args_str = args_str.strip()
#     # logging.info(args_str)
#     if(',' in args_str):
#         args_list = args_str.split(',')
#         logging.info(args_list)
#     else:
#         args_list.append(args_str)

#     typs = []
#     paras = []
#     count = 0
#     for i in args_list:
#         i = i.strip()
#         count += 1
#         typ = ''
#         para = ''
#         if(len(i.split(' ')) == 1):
#             typ = i.split(' ')[0]
#             para = 'ret_'+str(count)
#         elif(len(i.split(' ')) == 2):
#             typ,para = i.split(' ')
#         typs.append(typ)
#         paras.append(para)
            
#     return dict(zip(paras,typs))
        




# def get_fun_args(expr):
#     expr = expr.replace('(','')
#     expr = expr.replace(')','')
#     if(expr == '' or len(expr)==0):
#         return {}
#     args_list = expr.split(',')

#     typs = []
#     paras = []
#     for i in args_list:
#         # logging.info('args list==='+i)
#         typ,para = i.split(' ')
#         typs.append(typ)
#         paras.append(para)
#     logging.info(dict(zip(paras,typs)))
#     return dict(zip(paras,typs))

    




# if __name__ == "__main__":

#     path = '../varible.sol'
#     deal_raw_solidity(path)

    # expr = 'function fun1(uint a,uint b)pure public returns (uint b)'
    # define_function(expr)
    # func_llvm()
    # module = ir.Module(name = 'module')

    # a = ir.Argument(module,T.uint,'a')
    # fnty = ir.FunctionType(T.void,[T.uint])
    # func = ir.Function(module,fnty,name='function_name')
    # func.args = (a,)
    # print(module)

# module = ir.Module(name = "__name__")
# builder = ir.IRBuilder()
# # ld = builder.load()
# a = ir.PointerType(ir.IntType(16))
# ld = builder.load(a)
# print(ld)
# ret_args = {'1':1,'2':2}
# print()



