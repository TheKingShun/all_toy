import subprocess
import logging
import states as STATES
import os


logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s %(filename)s [line:%(lineno)d] ===%(levelname)s=== %(message)s',  # 显示格式
    datefmt='%Y %m %d',  # 日期
)
SSI = 'solc-select install'
SSU = 'solc-select use'
SSV = 'solc-select versions'

solc_version_supported = ['0.8.0','0.6.0','0.5.0','0.4.25','0.4.19','0.4.17','0.4.14']


def compile(path,version="0.4.19"):

    if(not os.path.exists(path) or not os.path.isfile(path)):
        logging.error('solidity path is not exists!!!')
        return 

    if(version not in solc_version_supported):
        logging.error('solc version is not supporting!!!')
        return 

    command = SSV
    result_cmd = run_cmd(command)
    if(result_cmd==STATES.ERROR):
        logging.error('cmd return value is ERROR')
        return

    if(version in result_cmd):
        res = solc_action(SSU,version)
        if(res == STATES.ERROR):
            logging.error(SSU +' '+version+' error!!!')
            return
    else:
        res1 = solc_action(SSI,version)
        res2 = solc_action(SSU,version)
        if(res1 == STATES.ERROR or res2 == STATES.ERROR):
            logging.error(SSU +' or '+SSI+' error!!!')
            return

    compile_file(path)



def compile_file(path):
    command = 'solc ' + path + ' --ast 1>ast.txt' 
    logging.info(command)
    ast_file_path = './ast.txt'
    res = run_cmd(command)
    if(res == STATES.ERROR):
        logging.error('compile error!')
        return 
    with open(ast_file_path,'r')as f:
        for line in f.readlines():
            print(line)
    return


def run_cmd(command):
 
    subp = subprocess.Popen(command,shell=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,encoding="utf-8")
    subp.wait(1)

    if subp.poll() == 0:
        logging.info("cmd run ok")
        cmd_out = subp.stdout.read()
        return(cmd_out)
    else:
        logging.error('cmd run error')
        return STATES.ERROR


def solc_action(action,version):
    if(action == SSI):
        command = SSI+' '+version
    elif(action == SSU):
        command = SSU+' '+version
    else:
        logging.error('solc action is not supporting!!!')
        return 

    res = run_cmd(command)
    if(res == STATES.ERROR):
        logging.error(action + version+" error!!!")
        return STATES.ERROR
    else:
        logging.info(action + version+' success!!!')
        return STATES.OK



if __name__ == "__main__":
    file_path = '../2.sol'
    sol_version='0.4.19'
    compile(file_path,sol_version)

