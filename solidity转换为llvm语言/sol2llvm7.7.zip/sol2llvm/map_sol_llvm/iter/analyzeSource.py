from llvmlite import ir
import re
import sol_type as T
import os
import llvm_header
import logging 
import define_gv as gv
import define_fun as df


logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s %(filename)s [line:%(lineno)d] ===%(levelname)s=== %(message)s',  # 显示格式
    datefmt='%Y %m %d',  # 日期
)

lexer = ['PragmaDirective','ContractDefinition','VariableDeclaration']
# not in function then the variable is global
is_in_fun = False

# ir Module
module = None
solidity_version=''
contract_name = ''
is_version_completed = False
is_contract_completed = False
dealed_path = './dealed.txt'
raw_data = []
current_in_function = False
current_system = 'ubuntu-20.04'
g_var = []



def deal_raw_solidity(path):
    if(os.path.exists(path) and os.path.isfile(path)):
        with open(path,'r')as f:
            lines = f.read()
            lines = lines.replace('{','')
            lines = lines.replace('}','')
            lines = lines.replace(';','')
        with open(dealed_path,'w')as f:
            f.write(lines)
        get_raw_data()


def get_raw_data():
    for line in open(dealed_path,'r'):
        line = line.strip()
        line = line.replace('\n','')
        if(line != ''):
            raw_data.append(line)
            # //todo
    analyze()
   

def analyze():

    global module

    solidity_version = raw_data[0]
    solidity_version = solidity_version.replace('pragma solidity','').strip();

    contract_name = raw_data[1]
    contract_name = contract_name.replace('contract','').strip()
    # creat module
    module = ir.Module(name = contract_name)
    module.data_layout = llvm_header.header[current_system]['datalayout']
    module.triple = llvm_header.header[current_system]['triple']


    for i in range(2,len(raw_data)):
        expr = raw_data[i]
        if(expr != ''):
            classify_expr(expr)
    
    print(module)



def classify_expr(expr):
    global module
    global g_var
    if gv.gv_no_init(module,expr,current_in_function,g_var) :
        logging.info('gv_no_init:'+expr)
        return 
    if gv.gv_with_init(module,expr,current_in_function,g_var):
        logging.info('gv_with_init:'+expr)
        return 
    if df.define_function(module,expr):
        logging.info('define_fun'+expr)
        return 
    
    

def delete_redun_lines(filename, count):
    fin = open(filename, 'r')
    a = fin.readlines()
    fout = open(filename, 'w')
    b = ''.join(a[count:])
    fout.write(b)

if __name__ == "__main__":
    path = '../varible.sol'
    deal_raw_solidity(path)























