from llvmlite import ir
import re
import sol_type as T
import os
import llvm_header
import logging 
import utils

g_var = []

def gv_no_init(module,expr,g_var_pre):
    global g_var
    g_var = g_var_pre
    if(';' in expr):
        expr = expr.replace(';','')
    expr = expr.strip()
    args = []
    temp = expr.strip().split(' ')
    args = [x for x in temp if x!='']
    if(len(args)==2 and args[0] in T.type_list ) :
        # no init gv
        define_global_var(module,T.all_types[args[0]],args[1])
        
        return True
    return False


def gv_with_init(module,expr,g_var_pre):
    global g_var
    g_var = g_var_pre
    args = []
    if('=' in expr  ):
        # logging.info('enter  \'=\' block!')
        # global var with init
        expr = expr.replace('=',' ')
        expr = expr.replace(';','')
        args = expr.split(' ')
        args = [x for x in args if x!='']
        # logging.info(args)
        if(len(args) == 3):
            if(utils.is_number(args[2]) and args[0] in T.type_list):
                # like uint a = 3
                # logging.info("like : uint a = 3 , define_global_var" )
                define_global_var(module,T.all_types[args[0]],args[1],args[2])
                return True
            else:
                #like uint b = a*2
                # todo
                return False
    return False


def define_global_var(module,type_sol,name,value=None):
    # global module
    # logging.info('define_global_var')
    if(module is None):return 
    # logging.info("creat gv")
    gv = ir.GlobalVariable(module,type_sol, name, addrspace=0)
    g_var.append(name)
    if(value is None):return 
    # logging.info("init gv")
    gv.initializer = type_sol(value)
    
    return 

