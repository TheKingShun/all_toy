from llvmlite import ir
import re
import sol_type as T
import os
import llvm_header
import logging 
import fun2llvm as f2l
import gv2llvm as gv2l
import utils

mod = None                          #ir.Module
func = None                         #ir.Function
builder = None                      #ir.IRBuilder
fun_para_2_ir_para = None           #函数参数映射到ir参数
body = None                         #函数方法体原始数据
gv = None                           #全局变量
lv = {}                             #局部变量表 用dict
fun_map = None




def prepare2ir(moudle,fun_map_pre,g_var):
    global mod 
    global fun_map
    global gv

    global func
    global fun_para_2_ir_para
    global body

    mod = moudle
    gv = g_var
    fun_map = fun_map_pre
    for f_name,f_info in fun_map.items():
        func = f_info.get('func')
        fun_para_2_ir_para = f_info.get('fp2ip')
        body  = f_info.get('f_body')
        body2ir()




"""
body2ir:获取函数的相应ir属性和函数的主题语句
"""
def body2ir():
    # global mod
    global func
    global builder
    # global fun_para_2_ir_para
    global body
    # global gv
    # global lv
    block = func.append_basic_block(name="start")               #对函数建立初始区块
    builder = ir.IRBuilder(block)
    get_ins(body)                                               #开始对指令进行解析


"""
get_ins:将原始的函数体字符串进行分解为相应的指令 放在指令list中 需要进行优化 因为逻辑上有不适配的情况存在
"""
def get_ins(body):
    body = body.strip()
    body = body.replace('\n','')

    # current instruction
    cur_ins = ''
    # symbol the end of this current ins
    ins_end = ';'
    # instructs list
    instructs = []
    tok = ['uint','uint8','uint16','uint32','uint64','uint256','return']
    tok2 = ['if','else','while']
    syb = ['+','-','*','/']
    for i in body:
        cur_ins += i
        if(cur_ins in tok2):
            ins_end = '}'


        if('throw;' in cur_ins):
            instructs.append(cur_ins.strip())
            cur_ins = ''
            ins_end = ';'

        if(i == ins_end):
            if(cur_ins != ''):
                instructs.append(cur_ins.strip())
            cur_ins = ''
            ins_end = ';'
    # print('==================instructs===============================')
    # print(instructs)
    for ins in instructs :
        analyze_ins(ins)


def analyze_ins(ins):
    typ = judge_ins(ins)
    if(typ == 0):
        #赋值语句的处理办法
        assign2ir(ins)
    if(typ == 3):
        ret2ir(ins)
    if(typ ==4):
        call2ir(ins)
        print("=======call2ir")



"""
judge_ins:判断ins的类型
0：赋值语句
1：判断语句
2：循环语句
3：返回语句
4:函数调用语句
"""
def judge_ins(ins):
    # todo此处的逻辑判断有漏洞 需要后续更改
    if('=' in ins ):return 0
    if('if' in ins or 'else' in ins or '==' in ins):return 1
    if('while' in ins or 'for' in ins):return 2
    if('return' in ins ):return 3
    else:return 4



"""
assign2ir:将指令完成类型判断后 进行转换（当前为赋值语句转化），转换的上下文在全局变量中已经声明
            假设当前的源码的指令集中的类型全为uint
"""
def assign2ir(ins):
    global mod
    global func
    global builder
    global fun_para_2_ir_para 
    # gv是一个包含全局变量名的列表 若要获取在ir中的表示 可以用module.get_global('xxx')
    global gv
    # lv是一个存储部变量的dict，若要获取在ir中的表示 可以用lv.get('xxx',default=None)
    global lv   

    lop = ins.split('=')[0]                                 #左操作:
    rop = ins.split('=')[-1].replace(';','').strip()        #右操作数
    var_name = lop.strip().split(' ')[-1]
    print(rop)
    if(not utils.is_number(rop)):
        print("===error=====current support single num to assign")
        return 
    rop = int(rop)

    if(var_name not in gv):

        if(lv.get(var_name) == None ):
            # this para is not in global and is a new stack variable
            var_typ = lop.strip().split(' ')[0]
            tmp = builder.alloca(T.all_types[var_typ],size = None,name = var_name)
            lv[var_name] = tmp
            # builder.store(T.uint(10086),dict_a['tmp'])
            # print("=============lv===============")
            # print(lv)
        builder.store(T.uint(rop),lv[var_name])

    else:
        builder.store(T.uint(rop),mod.get_global(var_name))






def ret2ir(ins):
    global mod
    global func
    global builder
    global fun_para_2_ir_para 
    global gv
    global lv   

    ins = ins.replace(';','').strip()
    ret_name = ins.split(' ')[-1]
    builder.ret(builder.load(lv.get(ret_name)))



def call2ir(ins):
    global builder
    global fun_map

    ins = ins.replace(";",'')
    f_name = ""
    for i in ins:
        if(i == '('):break; 
        f_name+=i
    
    ins = ins.replace(f_name,'')
    fun_args_given = str(re.findall(re.compile(r'[(](.*)[)]', re.S), ins)[0])           #被调用函数所需的参数
    if(fun_args_given != ''):
        given = fun_args_given.split(',')
    else:
        given = None

    fn = fun_map.get(f_name).get('func')
    args_typ = fun_map.get(f_name).get('raw_fun_paras')

    args = []
    logging.error((given))
    
    if(given is None):
        return builder.call(fn,args = ())
    else:
        for i in range(len(given)):
            args.append(build_value(args_typ[i],given[i]))
   
    logging.info('current builded args is:',args)

    return builder.call(fn,args = args)


"""
build_value:根据参数类型和参数值进行构建一个 IRType，当前仅支持整数
"""
def build_value(str_typ,str_value):
    if(str_typ == '' or str_value =='' ):
        logging.error('build value error!!!!')
        return 
    logging.info(str_typ)
    logging.info(str_value)
    logging.info(T.all_types[str_typ](int(str_value)))
    return T.all_types[str_typ](int(str_value))