
from llvmlite import ir
import re
import sol_type as T
import os
import llvm_header
import logging 
import fun_body2llvm as FB

module = None
g_var =None
fun_map_ir = None


def process_fun(module_pre,expr_fun,g_var_pre,fun_map_ir_pre):
    global fun_map_ir
    global g_var 
    # pattern = re.compile(r'[(](.*?)[)]' ,re.S)
    # args_str = str(re.findall(pattern,expr)[0])
    global module

    g_var= g_var_pre
    fun_map_ir = fun_map_ir_pre
    module = module_pre
    fun_name = ''
    fun_args = {}
    ret_args = None
    fun_body = (str(re.findall(re.compile(r'[{](.*)[}]', re.S), expr_fun)[0]))
    # print('==================fun_body===============================')
    # print(fun_body)

    expr = expr_fun.replace('function','')
    for i in expr:
        if(i == '('):
            break
        else:
            fun_name+=i
    fun_name = fun_name.strip()
    logging.info('fun name:==='+fun_name)
    expr = expr.replace(fun_name,'')
    fun_args_str = ''
    for i in expr:
        fun_args_str+=i
        if(i == ')'):
            break
    fun_args_str = fun_args_str.strip()
    logging.info('fun args:=='+fun_args_str)
    # get the function args returns the dict
    fun_args = get_fun_args(fun_args_str)
    logging.info(fun_args)
    if('returns' in expr):
        expr = expr.split('returns')[1]
        # get the ret value
        ret_args = get_ret_args(expr)
        # logging.info('returns==='+expr)
        logging.info('ret_args===')
        logging.info(ret_args)
    # creat the function LLVM
    logging.info(fun_args)
    fun2ir(fun_name,fun_args,ret_args,fun_body)

def fun2ir(fun_name,fun_args,ret_args,fun_body):
    global module
    global g_var
    ret_para = None
    ret_type = None
    fun_para = []
    fun_type = []
    fun_para_2_ir_para = {}
    logging.info(fun_args)
    logging.info(ret_args)
    if(ret_args is not None and len(ret_args)!=0):
        logging.info('ret_args length is '+str(len(ret_args)))
        for para,typ in ret_args.items():
            logging.info(para)
            logging.info(typ)
            ret_type = T.all_types[typ]
    

    for para ,typ in fun_args.items():
        logging.info(para)
        logging.info(typ)
        fun_para.append(para)
        fun_type.append(T.all_types[typ])
    logging.info(fun_type)
    if(ret_type is None):
        fnty = ir.FunctionType(T.void,fun_type)
    else:
        fnty = ir.FunctionType(ret_type,fun_type)
    

    func = ir.Function(module,fnty,name=fun_name)

    args_ir_para = func.args
    
    fun_para_2_ir_para = dict(zip(tuple(fun_args),args_ir_para))
    logging.info(fun_para_2_ir_para)

    block = func.append_basic_block(name="start")
    builder = ir.IRBuilder(block)

    logging.info(module.get_global('year'))
    logging.info((module.global_values))

    #store func to map

    # fun_map_ir[fun_name] = func,builder,fun_body,fun_para_2_ir_para

    # args = module,func,builder,fun_body,g_var,fun_para_2_ir_para,fun_map_ir
    # FB.body2ir(args)
    
    # return func,builder,fun_body,fun_para_2_ir_para



    # =============================temp ins==============================================
    # temp = builder.add(T.uint(2),T.uint(3),name='temp')
    # builder.sub(T.uint(9),T.uint(3))
    # builder.mul(T.uint(6),T.uint(2))
    # builder.udiv(T.uint(100),T.uint(1))
    # # builder.add(fun_para_2_ir_para['_a'],fun_para_2_ir_para['_c'])
    # builder.add(temp,temp,name = 'ret')

    # logging.info(module.get_global('year').type)
    # ld = builder.load(module.get_global('year'),name = 'global year')
    # builder.mul(ld,ld,name='ld')
    # logging.info(ld)
    # logging.info(module.global_values)
    # logging.info(func.args)

    # if(ret_args is None or len(ret_args) == 0 ):
    #     builder.ret_void()
        
    # else:
    #     builder.ret(T.all_types[list(ret_args.values())[0]](1))
    # logging.info(type( ir.PointerType('year')))
    # result = builder.fadd('year','year',name = "res")
    # builder.ret(result)
    # ================================temp ins=========================================
    

def get_ret_args(expr):
    args_list = []
    args_str = ''
    for i in expr:
        args_str += i
        if(i ==')'):
            break
    # logging.info('args_str==='+args_str)
    args_str = args_str.replace('(','')
    args_str = args_str.replace(')','')
    args_str = args_str.strip()
    # logging.info(args_str)
    if(',' in args_str):
        args_list = args_str.split(',')
        logging.info(args_list)
    else:
        args_list.append(args_str)

    typs = []
    paras = []
    count = 0
    for i in args_list:
        i = i.strip()
        count += 1
        typ = ''
        para = ''
        if(len(i.split(' ')) == 1):
            typ = i.split(' ')[0]
            para = 'ret_'+str(count)
        elif(len(i.split(' ')) == 2):
            typ,para = i.split(' ')
        typs.append(typ)
        paras.append(para)
            
    return dict(zip(paras,typs))
        




def get_fun_args(expr):
    expr = expr.replace('(','')
    expr = expr.replace(')','')
    if(expr == '' or len(expr)==0):
        return {}
    args_list = expr.split(',')

    typs = []
    paras = []
    for i in args_list:
        # logging.info('args list==='+i)
        typ,para = i.split(' ')
        typs.append(typ)
        paras.append(para)
    logging.info(dict(zip(paras,typs)))
    return dict(zip(paras,typs))
