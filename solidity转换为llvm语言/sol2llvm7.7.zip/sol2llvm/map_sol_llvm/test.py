
# def get_ins(line):
#     line = line.strip()
#     line = line.replace('\n','')

#     # current instruction
#     cur_ins = ''
#     # symbol the end of this current ins
#     ins_end = ';'
#     # instructs list
#     instructs = []
#     tok = ['uint','uint8','uint16','uint32','uint64','uint256','return']
#     tok2 = ['if','else','while']
#     syb = ['+','-','*','/']
#     for i in line:
#         cur_ins += i
        
#         if(cur_ins in tok2):
#             ins_end = '}'
        
#         if('throw;' in cur_ins):
#             instructs.append(cur_ins.strip())
#             cur_ins = ''
#             ins_end = ';'

#         if(i == ins_end):
#             if(cur_ins != ''):
#                 instructs.append(cur_ins.strip())
#             cur_ins = ''
#             ins_end = ';'
#     print('==================instructs===============================')
#     print(instructs)





# if(__name__ == "__main__"):
#     line = "\nuint tmp = _a * 8;\ntmp = tmp+2;\nuint result = tmp * 2 + 8 / 1;\nif(_a > 0){\n}\nelse{}\nreturn result;\n"
#     get_ins(line)

# from llvmlite  import ir
# import sol_type as T
# mod = ir.Module(name = "__name__")
# fnty = ir.FunctionType(T.void,[T.uint])
# func = ir.Function(mod,fnty,name='fun_name')
# block = func.append_basic_block(name="start")
# builder = ir.IRBuilder(block)

# tmp = builder.alloca(T.uint,size = None,name = 'tmp')
# dict_a = {}
# dict_a['tmp'] = tmp
# tmp_v = builder.load(dict_a['tmp'],name = 'tmp_value')
# tmp_t = builder.store(T.uint(10086),dict_a['tmp'])
# print(tmp_t)
# print(tmp_v)
# print(tmp)
# print(dict_a)
# print(int('123'))
a = ['a','b','c']
b = ['A','B','C']
args = []
for i in range(len(a)):
    args.append(a[i])
print(args)