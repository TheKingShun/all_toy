import re
from unicodedata import name
from llvmlite import ir
import sol_type as T
import os
import llvm_header
import logging 
import fun2llvm as f2l
import gv2llvm as gv2l
import utils


funs_map = None
mod  = None
raw_fun_paras=[]

def builds(_funs_map,module,expr):
    global funs_map
    global mod
    global raw_fun_paras
    mod = module
    funs_map = _funs_map

    fun_name = ''
    fun_args = {}

    ret_args = None
    fun_body = (str(re.findall(re.compile(r'[{](.*)[}]', re.S), expr)[0]))


    expr = expr.replace('function','')
    for i in expr:
        if(i == '('):
            break
        else:
            fun_name+=i
    fun_name = fun_name.strip()
    expr = expr.replace(fun_name,'')
    fun_args_str = ''
    for i in expr:
        fun_args_str+=i
        if(i == ')'):
            break
    fun_args_str = fun_args_str.strip()
    # get the function args returns the dict
    fun_args = get_fun_args(fun_args_str)
    if('returns' in expr):
        expr = expr.split('returns')[1]
        # get the ret value
        ret_args = get_ret_args(expr)

    # funinfo = fun_name,
    # funs_map[fun_name]
    ret_para = None
    ret_type = None
    fun_para = []
    fun_type = []
    fun_para_2_ir_para = {}

    logging.info(fun_args)
    logging.info(ret_args)
    if(ret_args is not None and len(ret_args)!=0):
        logging.info('ret_args length is '+str(len(ret_args)))
        for para,typ in ret_args.items():
            logging.info(para)
            logging.info(typ)
            ret_type = T.all_types[typ]
    

    for para ,typ in fun_args.items():
        logging.info(para)
        logging.info(typ)
        fun_para.append(para)
        fun_type.append(T.all_types[typ])
    logging.info(fun_type)

    if(ret_type is None):
        fnty = ir.FunctionType(T.void,fun_type)
    else:
        fnty = ir.FunctionType(ret_type,fun_type)
    

    func = ir.Function(module,fnty,name=fun_name)
    args_ir_para = func.args
    
    fun_para_2_ir_para = dict(zip(tuple(fun_args),args_ir_para))

    fun_info = fun_name,fun_para_2_ir_para,ret_type,fun_body,func
    fun_info = {
        'f_name':fun_name,
        'fp2ip':fun_para_2_ir_para,
        'r_type':ret_type,
        'f_body':fun_body,
        'func':func,
        'raw_fun_paras':raw_fun_paras
    }
    funs_map[fun_name] = fun_info

    # print("=================")
    # print(funs_map)






# =====================================================================

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



    



def get_ret_args(expr):
    args_list = []
    args_str = ''
    for i in expr:
        args_str += i
        if(i ==')'):
            break
    # logging.info('args_str==='+args_str)
    args_str = args_str.replace('(','')
    args_str = args_str.replace(')','')
    args_str = args_str.strip()
    # logging.info(args_str)
    if(',' in args_str):
        args_list = args_str.split(',')
    else:
        args_list.append(args_str)

    typs = []
    paras = []
    count = 0
    for i in args_list:
        i = i.strip()
        count += 1
        typ = ''
        para = ''
        if(len(i.split(' ')) == 1):
            typ = i.split(' ')[0]
            para = 'ret_'+str(count)
        elif(len(i.split(' ')) == 2):
            typ,para = i.split(' ')
        typs.append(typ)
        paras.append(para)
            
    return dict(zip(paras,typs))
        




def get_fun_args(expr):                                #原始类型的映射 a:uint
    global raw_fun_paras

    expr = expr.replace('(','')
    expr = expr.replace(')','')
    if(expr == '' or len(expr)==0):
        return {}
    args_list = expr.split(',')

    typs = []
    paras = []
    for i in args_list:
        # logging.info('args list==='+i)
        typ,para = i.split(' ')
        typs.append(typ)
        raw_fun_paras.append(typ)
        paras.append(para)
    # logging.info(dict(zip(paras,typs)))
    return dict(zip(paras,typs))


# if __name__ == "__main__":
#     expr = "function fun2(uint _a,uint _b) public{\nday = 10;\n}"
#     builds({},ir.Module(name = "mod"),expr)
